$(function() {
  $("#auto_complete_hotel_name").autocomplete({source: "/base2_cvb_auto_complete/hotels"});
});
